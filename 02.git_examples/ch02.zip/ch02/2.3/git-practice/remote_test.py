def remote_test():
  pass

if __name__=='__main__':
  remote_test()
  
